<ul class="livestats">
    <li>
        <span class="title">Used</span>
        <strong>{!! $used["value"] !!}<span>{!! $used["unit"] !!}</span></strong>
    </li>
    <li>
        <span class="title">Total</span>
        <strong>{!! $total["value"] !!}<span>{!! $total["unit"] !!}</span></strong>
    </li>
</ul>
