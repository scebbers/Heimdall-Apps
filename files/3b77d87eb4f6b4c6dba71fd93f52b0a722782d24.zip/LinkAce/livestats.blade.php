<ul class="livestats">
    <li>
        <span class="title">Links</span>
        <strong>{!! $links !!}</strong>
    </li>
    <li>
        <span class="title">Tags</span>
        <strong>{!! $tags !!}</strong>
    </li>
</ul>
