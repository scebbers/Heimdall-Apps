<?php

namespace App\SupportedApps\Tartube;

class Tartube extends \App\SupportedApps
{
}
