<?php

namespace App\SupportedApps\NotifiarrClient;

class NotifiarrClient extends \App\SupportedApps
{
}
