<?php

namespace App\SupportedApps\OmadaSDNController;

class OmadaSDNController extends \App\SupportedApps
{
}
