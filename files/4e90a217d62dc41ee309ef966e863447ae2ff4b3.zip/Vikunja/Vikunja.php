<?php

namespace App\SupportedApps\Vikunja;

class Vikunja extends \App\SupportedApps
{
}
