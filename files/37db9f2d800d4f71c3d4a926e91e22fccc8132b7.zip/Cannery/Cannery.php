<?php

namespace App\SupportedApps\Cannery;

class Cannery extends \App\SupportedApps
{
}
