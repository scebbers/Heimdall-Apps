<?php

namespace App\SupportedApps\MineOS;

class MineOS extends \App\SupportedApps
{
}
