<?php

namespace App\SupportedApps\Gardener;

class Gardener extends \App\SupportedApps
{
}
