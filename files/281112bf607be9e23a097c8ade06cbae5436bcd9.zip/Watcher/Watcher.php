<?php

namespace App\SupportedApps\Watcher;

class Watcher extends \App\SupportedApps
{
}
