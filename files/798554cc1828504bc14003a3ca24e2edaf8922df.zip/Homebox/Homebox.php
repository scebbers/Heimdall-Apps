<?php

namespace App\SupportedApps\Homebox;

class Homebox extends \App\SupportedApps
{
}
