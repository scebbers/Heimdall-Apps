<?php

namespace App\SupportedApps\KubernetesDashboard;

class KubernetesDashboard extends \App\SupportedApps
{
}
