<?php

namespace App\SupportedApps\Longhorn;

class Longhorn extends \App\SupportedApps
{
}
