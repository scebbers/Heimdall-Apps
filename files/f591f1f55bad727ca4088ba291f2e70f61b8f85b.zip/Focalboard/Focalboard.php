<?php

namespace App\SupportedApps\Focalboard;

class Focalboard extends \App\SupportedApps
{
}
