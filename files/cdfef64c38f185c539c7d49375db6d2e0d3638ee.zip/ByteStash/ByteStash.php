<?php

namespace App\SupportedApps\ByteStash;

class ByteStash extends \App\SupportedApps
{
}
