<?php

namespace App\SupportedApps\Bludit;

class Bludit extends \App\SupportedApps
{
}
