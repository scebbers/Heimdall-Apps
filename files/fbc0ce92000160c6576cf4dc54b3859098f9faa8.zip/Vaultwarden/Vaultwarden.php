<?php

namespace App\SupportedApps\Vaultwarden;

class Vaultwarden extends \App\SupportedApps
{
}
