<?php

namespace App\SupportedApps\Zwavejs2Mqtt;

class Zwavejs2Mqtt extends \App\SupportedApps
{
}
