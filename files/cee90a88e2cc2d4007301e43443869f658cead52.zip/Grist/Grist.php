<?php

namespace App\SupportedApps\Grist;

class Grist extends \App\SupportedApps
{
}
