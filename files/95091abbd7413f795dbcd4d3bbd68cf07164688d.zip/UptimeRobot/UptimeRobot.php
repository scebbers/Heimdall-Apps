<?php

namespace App\SupportedApps\UptimeRobot;

class UptimeRobot extends \App\SupportedApps
{
}
