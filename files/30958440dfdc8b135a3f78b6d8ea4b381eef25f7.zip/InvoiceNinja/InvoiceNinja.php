<?php

namespace App\SupportedApps\InvoiceNinja;

class InvoiceNinja extends \App\SupportedApps
{
}
