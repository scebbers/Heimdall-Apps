<?php

namespace App\SupportedApps\FreshTomato;

class FreshTomato extends \App\SupportedApps
{
}
