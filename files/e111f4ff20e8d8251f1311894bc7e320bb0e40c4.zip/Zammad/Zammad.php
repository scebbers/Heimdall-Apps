<?php

namespace App\SupportedApps\Zammad;

class Zammad extends \App\SupportedApps
{
}
