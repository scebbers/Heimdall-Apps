<ul class="livestats">
    <li>
        <span class="title">Published</span>
        <strong>{!! $published !!}</strong>
    </li>
    <li>
        <span class="title">Draft</span>
        <strong>{!! $draft !!}</strong>
    </li>
</ul>
